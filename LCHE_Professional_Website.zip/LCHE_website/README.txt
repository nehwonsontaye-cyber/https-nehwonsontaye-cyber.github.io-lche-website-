# LCHE Website

Liberia Community Health Education (LCHE)
Established March 25, 2014

## Files
- index.html — main website
- styles.css — responsive design and colors
- script.js — mobile menu, year and demo contact form
- assets/lche-logo.png — LCHE logo

## How to view
Open `index.html` in a modern web browser.

## Before publishing
Replace the placeholder contact information with LCHE's official:
- office address
- phone number
- email address
- social-media pages

The contact form is currently a demonstration form. It should be connected to an email/form service or backend before production use.
