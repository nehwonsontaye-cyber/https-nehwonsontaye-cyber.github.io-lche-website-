const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

toggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(open));
});

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

function submitForm(event) {
  event.preventDefault();
  const msg = document.getElementById("form-message");
  msg.textContent = "Thank you. This demonstration form is ready to be connected to an LCHE email or website form service.";
  event.target.reset();
  return false;
}
